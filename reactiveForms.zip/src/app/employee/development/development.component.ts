import { Component, OnInit } from "@angular/core";
import {  FormBuilder, FormControl, FormGroup, FormArray } from "@angular/forms";

@Component({
  selector: "app-development",
  templateUrl: "./development.component.html",
  styleUrls: ["./development.component.css"]
})
export class DevelopmentComponent implements OnInit {
  items = [
    {
      name: "Jon",
      gender: "Male"
    },
    {
      name: "Dog",
      gender: "Male"
    },
    {
      name: "Maris",
      gender: "Male"
    }
  ];
  names = new FormControl("");
  isP = false;
  profileForm = new FormGroup({
    firstName: new FormControl(""),
    lastName: new FormControl(""),
    address: new FormGroup({
      street: new FormControl(""),
      city: new FormControl(""),
      state: new FormControl(""),
      zip: new FormControl("")
    }),
    aliases: this.fb.array([
      this.fb.control('')
    ])
  });

  constructor(private fb: FormBuilder) { }

  ngOnInit() {}

  updateName() {
    this.isP = true;
    this.names.setValue("Nancy");
  }

  onSubmit() {
    console.warn(this.profileForm.value);
  }
}
