import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl } from "@angular/forms";

@Component({
  selector: "app-list-employee",
  templateUrl: "./list-employee.component.html",
  styleUrls: ["./list-employee.component.css"]
})
export class ListEmployeeComponent implements OnInit {
  employeeForm: FormGroup;
  constructor() {}

  ngOnInit() {
    this.employeeForm = new FormGroup({
      fullName: new FormControl(),
      email: new FormControl(),
      skils: new FormGroup({
        skillName: new FormControl(),
        subjet: new FormControl()
      })
    });
    // Object.keys(this.employeeForm.controls).forEach(key => {
    //   this.employeeForm.controls[key].markAsDirty();
    // });
  }

  onSubmit() {
    console.log(this.employeeForm.value);
  }
}
